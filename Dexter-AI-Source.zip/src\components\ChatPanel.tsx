import { useEffect, useRef } from "react";

interface Message {
  role: "user" | "dexter";
  text: string;
  intent?: string;
  confidence?: number;
  reasoning?: string;
  suggestions?: string[];
}

interface ChatPanelProps {
  messages: Message[];
  thinking: boolean;
  onSend: (text: string) => void;
  inputText: string;
  onInputChange: (text: string) => void;
}

function getIntentLabel(intent: string): string {
  const labels: Record<string, string> = {
    workspace_optimization: "Optimize Workspace",
    focus_mode: "Focus Mode",
    calm_mode: "Calm Mode",
    performance_mode: "Performance",
    workspace_gaming: "Gaming Setup",
    workspace_coding: "Coding Setup",
    workspace_study: "Study Setup",
    launch_app: "Launch App",
    close_app: "Close App",
    system_query: "System Info",
    media_control: "Media",
    conversation: "Chat",
  };
  return labels[intent] || intent.replace(/_/g, " ");
}

function getIntentColor(intent: string): string {
  const colors: Record<string, string> = {
    workspace_optimization: "bg-dexter-cyan/20 text-dexter-cyan border-dexter-cyan/30",
    focus_mode: "bg-dexter-green/20 text-dexter-green border-dexter-green/30",
    calm_mode: "bg-blue-900/30 text-blue-300 border-blue-800/30",
    performance_mode: "bg-yellow-900/30 text-yellow-300 border-yellow-800/30",
    workspace_gaming: "bg-purple-900/30 text-purple-300 border-purple-800/30",
    workspace_coding: "bg-cyan-900/30 text-cyan-300 border-cyan-800/30",
    workspace_study: "bg-indigo-900/30 text-indigo-300 border-indigo-800/30",
  };
  return colors[intent] || "bg-dexter-cyan/10 text-dexter-cyan border-dexter-cyan/20";
}

export default function ChatPanel({
  messages,
  thinking,
}: ChatPanelProps) {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="flex-1 overflow-y-auto px-4 py-2 space-y-3">
      {messages.length === 0 && (
        <div className="text-center py-12 text-dexter-dim/50">
          <p className="text-sm">Ask Dexter anything</p>
          <p className="text-xs mt-1">
            "This feels messy" · "Help me focus" · "Open my gaming setup"
          </p>
        </div>
      )}
      {messages.map((msg, i) => (
        <div
          key={i}
          className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} fade-in`}
        >
          <div
            className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm ${
              msg.role === "user"
                ? "bg-dexter-cyan/10 border border-dexter-cyan/20 text-dexter-white"
                : "glass text-dexter-white"
            }`}
          >
            {msg.role === "dexter" && (
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-dexter-cyan shadow-glow" />
                  <span className="text-[10px] font-mono text-dexter-cyan uppercase tracking-wider">
                    Dexter
                  </span>
                </div>
                {msg.intent && msg.intent !== "conversation" && (
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded-full border ${getIntentColor(
                      msg.intent
                    )}`}
                  >
                    {getIntentLabel(msg.intent)}
                  </span>
                )}
                {msg.confidence !== undefined && (
                  <span className="text-[9px] text-dexter-dim/50 font-mono">
                    {Math.round(msg.confidence * 100)}%
                  </span>
                )}
              </div>
            )}
            <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>

            {msg.role === "dexter" && msg.suggestions && msg.suggestions.length > 0 && (
              <div className="mt-2 pt-2 border-t border-dexter-border/50 space-y-1">
                {msg.suggestions.map((s, si) => (
                  <p
                    key={si}
                    className="text-[11px] text-dexter-cyan/70 italic leading-tight"
                  >
                    💡 {s}
                  </p>
                ))}
              </div>
            )}
          </div>
        </div>
      ))}
      {thinking && (
        <div className="flex justify-start fade-in">
          <div className="glass rounded-2xl px-4 py-3">
            <div className="flex items-center gap-1.5 mb-1">
              <div className="w-2 h-2 rounded-full bg-dexter-cyan/50 animate-pulse" />
              <span className="text-[10px] font-mono text-dexter-cyan/50 uppercase">
                Analyzing intent
              </span>
            </div>
            <div className="flex gap-1 mt-1">
              <div className="w-1.5 h-1.5 rounded-full bg-dexter-cyan animate-bounce" style={{ animationDelay: "0s" }} />
              <div className="w-1.5 h-1.5 rounded-full bg-dexter-cyan animate-bounce" style={{ animationDelay: "0.15s" }} />
              <div className="w-1.5 h-1.5 rounded-full bg-dexter-cyan animate-bounce" style={{ animationDelay: "0.3s" }} />
            </div>
          </div>
        </div>
      )}
      <div ref={endRef} />
    </div>
  );
}
