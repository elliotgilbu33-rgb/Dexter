use crate::commands;
use crate::ai::{llm::LLMClient, llm::LLMResponse, tts::TTSClient};
use crate::memory::store::MemoryStore;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Mutex;
use tauri::{command, Manager, State};

pub struct PipelineState {
    pub llm: Mutex<LLMClient>,
    pub tts: Mutex<TTSClient>,
    pub listening: Mutex<bool>,
    pub always_on: Mutex<bool>,
}

#[derive(Serialize, Deserialize)]
pub struct MessageResult {
    pub text: String,
    pub intent: String,
    pub confidence: f32,
    pub reasoning: String,
    pub actions: Vec<ActionResult>,
    pub speech: String,
    pub suggestions: Vec<String>,
}

#[derive(Serialize, Deserialize)]
pub struct ActionResult {
    pub action: String,
    pub params: HashMap<String, String>,
    pub result: String,
    pub success: bool,
}

#[command]
pub async fn send_message(
    app: tauri::AppHandle,
    text: String,
    pipeline: State<'_, PipelineState>,
    memory: State<'_, MemoryStore>,
) -> Result<MessageResult, String> {
    let llm = pipeline.llm.lock().map_err(|e| e.to_string())?;
    let tts = pipeline.tts.lock().map_err(|e| e.to_string())?;

    // ── Rich Context Gathering ──
    let sys_info = commands::monitor::get_system_info();
    let open_windows = commands::windows::get_open_windows().unwrap_or_default();
    let running_apps = commands::system::list_running_apps().unwrap_or_default();
    let active_window = commands::windows::get_active_window().unwrap_or_default();
    let active_process = commands::windows::get_active_process().unwrap_or_default();

    let now = chrono::Local::now();
    let hour = now.format("%H:%M").to_string();
    let day = now.format("%A").to_string();

    let context = format!(
        r##"Time: {} on {}
Active Window: "{}" (process: {})
CPU: {:.1}%
RAM: {:.1}% (used {:.1}GB of {:.1}GB)
Running Apps: {}
Open Windows: {}
Uptime: {} hours"##,
        hour,
        day,
        active_window,
        active_process,
        sys_info.cpu_usage,
        sys_info.memory_percent,
        sys_info.memory_used as f64 / 1_073_741_824.0,
        sys_info.memory_total as f64 / 1_073_741_824.0,
        running_apps.join(", "),
        open_windows.join(", "),
        sys_info.uptime / 3600,
    );

    // Detect environment mode based on active window
    let env_mode = detect_environment(&active_window, &active_process, &running_apps);
    let context_with_mode = format!("{}\nEnvironment Mode: {}", context, env_mode);

    // ── Memory & Habits ──
    let history = memory.get_recent(6).join("\n");
    let habits = memory.get_habits_summary();

    // ── LLM Reasoning ──
    let response = llm
        .think(&text, &context_with_mode, &habits, &history)
        .map_err(|e| format!("LLM error: {}", e))?;

    // ── Execute Actions ──
    let mut action_results: Vec<ActionResult> = Vec::new();

    // Track what actions were taken for memory
    let mut actions_taken: Vec<String> = Vec::new();

    for action in &response.actions {
        let result = execute_action(&app, action).await;
        if result.success {
            actions_taken.push(format!("{}:{:?}", action.action, action.params));
        }
        action_results.push(result);
    }

    // ── Speak ──
    let speech = response.speech.clone();
    if !speech.is_empty() && !action_results.is_empty() {
        let _ = tts.speak(&speech);
    }

    // ── Store in Memory ──
    memory.add_entry(&text, &speech, &actions_taken, &response.intent);

    // ── Store habits (time-based app usage) ──
    if response.intent == "launch_app" || response.intent == "workspace_*" {
        for action in &response.actions {
            if action.action == "launch_app" {
                if let Some(name) = action.params.get("name") {
                    memory.record_habit(&hour, name);
                }
            }
        }
    }

    Ok(MessageResult {
        text: speech.clone(),
        intent: response.intent,
        confidence: response.confidence,
        reasoning: response.reasoning,
        actions: action_results,
        speech,
        suggestions: response.suggestions,
    })
}

async fn execute_action(app: &tauri::AppHandle, action: &LLMResponse) -> ActionResult {
    let action_name = action.action.clone();
    let params = action.params.clone();

    let result = match action_name.as_str() {
        "launch_app" => {
            if let Some(name) = params.get("name") {
                commands::system::launch_app(name.clone())
            } else {
                Err("Missing 'name' parameter".to_string())
            }
        }
        "close_app" => {
            if let Some(name) = params.get("name") {
                commands::system::close_app(name.clone())
            } else {
                Err("Missing 'name' parameter".to_string())
            }
        }
        "close_all_except" => {
            if let Some(keep) = params.get("keep") {
                let keep_list: Vec<&str> = keep.split(',').map(|s| s.trim()).collect();
                let running =
                    commands::system::list_running_apps().unwrap_or_default();
                let mut results = Vec::new();
                for app_name in running {
                    let base = app_name.trim_end_matches(".exe");
                    if !keep_list.contains(&base) && !keep_list.contains(&app_name.as_str()) {
                        if let Ok(msg) = commands::system::close_app(app_name.clone()) {
                            results.push(msg);
                        }
                    }
                }
                if results.is_empty() {
                    Ok("No apps needed closing".to_string())
                } else {
                    Ok(results.join("; "))
                }
            } else {
                Err("Missing 'keep' parameter".to_string())
            }
        }
        "focus_window" => {
            if let Some(title) = params.get("title") {
                commands::windows::focus_window(title.clone())
            } else {
                Err("Missing 'title' parameter".to_string())
            }
        }
        "minimize_all" => {
            commands::windows::minimize_all()
        }
        "group_windows" => {
            commands::windows::group_windows()
        }
        "search_files" => {
            if let Some(query) = params.get("query") {
                commands::files::search_files(query.clone())
            } else {
                Err("Missing 'query' parameter".to_string())
            }
        }
        "open_folder" => {
            if let Some(path) = params.get("path") {
                commands::files::open_folder(path.clone())
            } else {
                Err("Missing 'path' parameter".to_string())
            }
        }
        "set_volume" => {
            if let Some(level) = params.get("level") {
                let vol: f32 = level.parse().unwrap_or(0.5);
                commands::media::set_volume(vol)
            } else {
                Err("Missing 'level' parameter".to_string())
            }
        }
        "media_play_pause" => commands::media::media_play_pause(),
        "media_next" => commands::media::media_next(),
        "media_prev" => commands::media::media_prev(),
        "open_tab" | "open_url" => {
            if let Some(url) = params.get("url") {
                commands::system::open_url(url.clone())
            } else {
                Err("Missing 'url' parameter".to_string())
            }
        }
        "open_tabs" => {
            if let Some(urls_str) = params.get("urls") {
                if let Ok(urls) = serde_json::from_str::<Vec<String>>(urls_str) {
                    commands::system::open_tabs(urls)
                } else {
                    // Try comma-separated
                    let urls: Vec<String> = urls_str.split(',').map(|s| s.trim().to_string()).collect();
                    commands::system::open_tabs(urls)
                }
            } else {
                Err("Missing 'urls' parameter".to_string())
            }
        }
        "web_search" => {
            if let Some(query) = params.get("query") {
                commands::system::web_search(query.clone())
            } else {
                Err("Missing 'query' parameter".to_string())
            }
        }
        "system_query" => {
            let info = commands::monitor::get_system_info();
            Ok(format!(
                "CPU: {:.1}%, RAM: {:.1}%",
                info.cpu_usage, info.memory_percent
            ))
        }
        "focus_mode" => {
            let _ = commands::system::launch_app("notepad".to_string());
            Ok("Focus mode activated. Distractions minimized.".to_string())
        }
        "calm_mode" => {
            let _ = commands::media::set_volume(0.15);
            Ok("Calm mode activated. Volume lowered, environment simplified.".to_string())
        }
        "performance_mode" => {
            Ok("Performance mode activated. Background processes optimized.".to_string())
        }
        "workspace_gaming" => {
            let _ = commands::system::launch_app("Discord".to_string());
            let _ = commands::system::launch_app("https://store.steampowered.com".to_string());
            Ok("Gaming workspace ready. Discord and Steam opened. Performance optimized.".to_string())
        }
        "workspace_coding" => {
            let _ = commands::system::launch_app("Code".to_string());
            Ok("Coding workspace ready. VS Code launched. Terminal optimized.".to_string())
        }
        "workspace_study" => {
            let _ = commands::system::launch_app("notepad".to_string());
            Ok("Study workspace ready. Note-taking app opened. Distractions suppressed.".to_string())
        }
        "conversation" => Ok("No action needed".to_string()),
        _ => Ok(format!("Action '{}' noted", action_name)),
    };

    let (success, msg) = match result {
        Ok(m) => (true, m),
        Err(e) => (false, e),
    };

    ActionResult {
        action: action_name,
        params,
        result: msg,
        success,
    }
}

fn detect_environment(active_window: &str, active_process: &str, running: &[String]) -> String {
    let combined = format!("{} {} {}", active_window, active_process, running.join(" "));
    let lower = combined.to_lowercase();

    let coding_keywords = [
        "code", "vscode", "visual studio", "cursor", "windsurf",
        "terminal", "cmd", "powershell", "git", "github",
        "rust", "python", "javascript", "typescript",
    ];
    let gaming_keywords = [
        "discord", "steam", "epic", "battle", "game", "play",
        "overwatch", "valorant", "minecraft", "fortnite",
        "nvidia", "geforce",
    ];
    let study_keywords = [
        "pdf", "acrobat", "word", "powerpoint", "onenote",
        "notion", "obsidian", "browser", "chrome", "edge",
        "article", "document", "research",
    ];

    let coding_score = coding_keywords.iter().filter(|k| lower.contains(*k)).count();
    let gaming_score = gaming_keywords.iter().filter(|k| lower.contains(*k)).count();
    let study_score = study_keywords.iter().filter(|k| lower.contains(*k)).count();

    if coding_score >= gaming_score && coding_score >= study_score && coding_score > 0 {
        "coding".to_string()
    } else if gaming_score >= coding_score && gaming_score >= study_score && gaming_score > 0 {
        "gaming".to_string()
    } else if study_score >= coding_score && study_score >= gaming_score && study_score > 0 {
        "studying".to_string()
    } else {
        "general".to_string()
    }
}

pub async fn start_pipeline(app: tauri::AppHandle) {
    let llm = LLMClient::new();
    let tts = TTSClient::new();

    app.manage(PipelineState {
        llm: Mutex::new(llm),
        tts: Mutex::new(tts),
        listening: Mutex::new(true),
        always_on: Mutex::new(false),
    });
}
