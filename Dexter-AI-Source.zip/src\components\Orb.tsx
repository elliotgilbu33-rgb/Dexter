import { useEffect, useRef } from "react";

interface OrbProps {
  listening: boolean;
  speaking: boolean;
  thinking: boolean;
  onClick: () => void;
}

export default function Orb({ listening, speaking, thinking, onClick }: OrbProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const timeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    const size = 80;
    canvas.width = size * 2;
    canvas.height = size * 2;

    const animate = (t: number) => {
      timeRef.current = t / 1000;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const cx = canvas.width / 2 + mouseRef.current.x * 4;
      const cy = canvas.height / 2 + mouseRef.current.y * 4;
      const baseRadius = size - 8;

      // Outer glow ring
      const gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, baseRadius + 24);
      gradient.addColorStop(0, "rgba(0, 212, 255, 0)");
      gradient.addColorStop(0.5, `rgba(0, 212, 255, ${listening ? 0.15 : 0.05})`);
      gradient.addColorStop(1, "rgba(0, 212, 255, 0)");
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(cx, cy, baseRadius + 24, 0, Math.PI * 2);
      ctx.fill();

      // Pulsing outer ring
      const pulse = listening ? Math.sin(t / 400) * 0.5 + 0.5 : 0;
      ctx.strokeStyle = `rgba(0, 212, 255, ${0.1 + pulse * 0.2})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, baseRadius + 8 + pulse * 6, 0, Math.PI * 2);
      ctx.stroke();

      // Core orb
      const glowIntensity = speaking ? 0.8 : thinking ? 0.5 : listening ? 0.4 : 0.15;
      const coreGrad = ctx.createRadialGradient(
        cx - 8, cy - 8, 0,
        cx, cy, baseRadius
      );

      if (speaking) {
        coreGrad.addColorStop(0, "#00ff88");
        coreGrad.addColorStop(0.3, "#00d4ff");
        coreGrad.addColorStop(0.7, "#0066ff");
        coreGrad.addColorStop(1, "#0a0a0f");
      } else if (thinking) {
        coreGrad.addColorStop(0, "#00d4ff");
        coreGrad.addColorStop(0.4, "#0066ff");
        coreGrad.addColorStop(1, "#0a0a0f");
      } else if (listening) {
        coreGrad.addColorStop(0, "#00d4ff");
        coreGrad.addColorStop(0.5, "#0066ff");
        coreGrad.addColorStop(1, "#0a0a0f");
      } else {
        coreGrad.addColorStop(0, "rgba(0, 212, 255, 0.3)");
        coreGrad.addColorStop(1, "#0a0a0f");
      }
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, baseRadius, 0, Math.PI * 2);
      ctx.fill();

      // Glow overlay
      ctx.shadowColor = listening ? "#00d4ff" : "transparent";
      ctx.shadowBlur = listening ? 30 + pulse * 20 : 0;

      // Inner shimmer
      if (listening || speaking) {
        const shimmer = ctx.createRadialGradient(
          cx - 20, cy - 20, 0,
          cx, cy, baseRadius
        );
        shimmer.addColorStop(0, "rgba(255,255,255,0.15)");
        shimmer.addColorStop(0.5, "rgba(255,255,255,0.05)");
        shimmer.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = shimmer;
        ctx.beginPath();
        ctx.arc(cx, cy, baseRadius, 0, Math.PI * 2);
        ctx.fill();
      }

      animId = requestAnimationFrame(animate);
    };

    animId = requestAnimationFrame(animate);

    const handleMouse = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: (e.clientX - rect.left - rect.width / 2) / rect.width,
        y: (e.clientY - rect.top - rect.height / 2) / rect.height,
      };
    };

    canvas.addEventListener("mousemove", handleMouse);
    return () => {
      cancelAnimationFrame(animId);
      canvas.removeEventListener("mousemove", handleMouse);
    };
  }, [listening, speaking, thinking]);

  return (
    <canvas
      ref={canvasRef}
      onClick={onClick}
      className="cursor-pointer transition-transform hover:scale-105 active:scale-95 no-drag"
      style={{ width: 80, height: 80 }}
    />
  );
}
