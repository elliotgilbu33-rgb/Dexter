import { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/core";

interface SystemInfo {
  cpu: number;
  ram: number;
  cpuUsage: number;
  memoryUsed: number;
  memoryTotal: number;
  memoryPercent: number;
}

export function useSystemInfo() {
  const [info, setInfo] = useState<SystemInfo>({
    cpu: 0,
    ram: 0,
    cpuUsage: 0,
    memoryUsed: 0,
    memoryTotal: 0,
    memoryPercent: 0,
  });

  useEffect(() => {
    const poll = async () => {
      try {
        const data: any = await invoke("get_system_info");
        setInfo({
          cpu: data.cpu_usage,
          ram: data.memory_percent,
          cpuUsage: data.cpu_usage,
          memoryUsed: data.memory_used,
          memoryTotal: data.memory_total,
          memoryPercent: data.memory_percent,
        });
      } catch {}
    };

    poll();
    const interval = setInterval(poll, 2000);
    return () => clearInterval(interval);
  }, []);

  return info;
}
