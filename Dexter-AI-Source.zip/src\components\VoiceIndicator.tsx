interface VoiceIndicatorProps {
  listening: boolean;
  speaking: boolean;
  thinking: boolean;
}

export default function VoiceIndicator({
  listening,
  speaking,
  thinking,
}: VoiceIndicatorProps) {
  const getStateText = () => {
    if (speaking) return "Speaking";
    if (thinking) return "Thinking";
    if (listening) return "Listening";
    return "Standby";
  };

  const getStateColor = () => {
    if (speaking) return "text-dexter-green";
    if (thinking) return "text-dexter-cyan";
    if (listening) return "text-dexter-cyan";
    return "text-dexter-dim";
  };

  return (
    <span
      className={`text-[10px] font-mono uppercase tracking-widest ${getStateColor()} transition-colors duration-300`}
    >
      {getStateText()}
    </span>
  );
}
