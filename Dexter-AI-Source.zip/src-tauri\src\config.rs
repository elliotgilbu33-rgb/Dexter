use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;
use std::sync::Mutex;
use tauri::{command, State};

#[derive(Serialize, Deserialize, Clone)]
pub struct DexterConfig {
    pub llm_model: String,
    pub voice: String,
    pub wake_word_enabled: bool,
    pub always_on: bool,
    pub auto_start: bool,
    pub volume: f32,
}

impl Default for DexterConfig {
    fn default() -> Self {
        DexterConfig {
            llm_model: "qwen2.5:3b".to_string(),
            voice: "en_US-ryan-medium".to_string(),
            wake_word_enabled: true,
            always_on: false,
            auto_start: true,
            volume: 0.5,
        }
    }
}

impl DexterConfig {
    pub fn load() -> Self {
        let config_path = Self::config_path();
        fs::read_to_string(&config_path)
            .ok()
            .and_then(|content| serde_json::from_str(&content).ok())
            .unwrap_or_default()
    }

    pub fn save(&self) {
        let config_path = Self::config_path();
        if let Some(parent) = config_path.parent() {
            let _ = fs::create_dir_all(parent);
        }
        if let Ok(content) = serde_json::to_string_pretty(self) {
            let _ = fs::write(&config_path, content);
        }
    }

    fn config_path() -> PathBuf {
        dirs::data_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join("DexterAI")
            .join("config.json")
    }
}

pub struct ConfigState {
    pub inner: Mutex<DexterConfig>,
}

impl ConfigState {
    pub fn new() -> Self {
        ConfigState {
            inner: Mutex::new(DexterConfig::load()),
        }
    }
}

#[command]
pub fn get_config(state: State<'_, ConfigState>) -> DexterConfig {
    state.inner.lock().unwrap().clone()
}

#[command]
pub fn update_config(state: State<'_, ConfigState>, new_config: DexterConfig) -> String {
    if let Ok(mut config) = state.inner.lock() {
        *config = new_config.clone();
        config.save();
        "Config updated".to_string()
    } else {
        "Failed to update config".to_string()
    }
}
