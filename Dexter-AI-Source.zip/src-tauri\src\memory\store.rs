use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Mutex;
use tauri::State;
use std::fs;

#[derive(Serialize, Deserialize, Clone)]
pub struct MemoryEntry {
    pub timestamp: String,
    pub user_text: String,
    pub dexter_text: String,
    pub actions: Vec<String>,
    pub intent: String,
}

#[derive(Serialize, Deserialize, Clone, Default)]
pub struct Habit {
    pub pattern: String,
    pub frequency: u32,
    pub last_seen: String,
    pub context: String,
}

pub struct MemoryStore {
    entries: Mutex<Vec<MemoryEntry>>,
    habits: Mutex<Vec<Habit>>,
    db_path: PathBuf,
    habits_path: PathBuf,
}

impl MemoryStore {
    pub fn new(base_path: Option<PathBuf>) -> Self {
        let data_dir = base_path.unwrap_or_else(|| PathBuf::from("."));
        let db_path = data_dir.join("memory.json");
        let habits_path = data_dir.join("habits.json");

        let entries: Vec<MemoryEntry> = fs::read_to_string(&db_path)
            .ok()
            .and_then(|content| serde_json::from_str(&content).ok())
            .unwrap_or_default();

        let habits: Vec<Habit> = fs::read_to_string(&habits_path)
            .ok()
            .and_then(|content| serde_json::from_str(&content).ok())
            .unwrap_or_default();

        MemoryStore {
            entries: Mutex::new(entries),
            habits: Mutex::new(habits),
            db_path,
            habits_path,
        }
    }

    pub fn add_entry(
        &self,
        user_text: &str,
        dexter_text: &str,
        actions: &[String],
        intent: &str,
    ) {
        if let Ok(mut entries) = self.entries.lock() {
            let timestamp = chrono::Local::now().format("%Y-%m-%d %H:%M:%S").to_string();

            let entry = MemoryEntry {
                timestamp,
                user_text: user_text.to_string(),
                dexter_text: dexter_text.to_string(),
                actions: actions.to_vec(),
                intent: intent.to_string(),
            };

            entries.push(entry);
            if entries.len() > 200 {
                entries.remove(0);
            }

            let _ = fs::write(
                &self.db_path,
                serde_json::to_string(&*entries).unwrap_or_default(),
            );
        }
    }

    pub fn get_recent(&self, count: usize) -> Vec<String> {
        if let Ok(entries) = self.entries.lock() {
            let len = entries.len();
            let slice = if len <= count {
                &entries[..]
            } else {
                &entries[len - count..]
            };
            slice
                .iter()
                .map(|e| {
                    format!(
                        "[{}] User: {} → Dexter: {}",
                        e.timestamp, e.user_text, e.dexter_text
                    )
                })
                .collect()
        } else {
            vec![]
        }
    }

    // ── Habit Tracking ──

    pub fn record_habit(&self, time: &str, app_name: &str) {
        if let Ok(mut habits) = self.habits.lock() {
            let pattern = format!("opens_{}_at_{}", app_name.to_lowercase(), time);
            let now = chrono::Local::now().format("%Y-%m-%d %H:%M").to_string();

            if let Some(existing) = habits.iter_mut().find(|h| h.pattern == pattern) {
                existing.frequency += 1;
                existing.last_seen = now.clone();
            } else {
                habits.push(Habit {
                    pattern,
                    frequency: 1,
                    last_seen: now.clone(),
                    context: format!("{} at {}", app_name, time),
                });
            }

            // Keep top 50 habits
            habits.sort_by(|a, b| b.frequency.cmp(&a.frequency));
            if habits.len() > 50 {
                habits.truncate(50);
            }

            let _ = fs::write(
                &self.habits_path,
                serde_json::to_string(&*habits).unwrap_or_default(),
            );
        }
    }

    pub fn get_habits_summary(&self) -> String {
        if let Ok(habits) = self.habits.lock() {
            let top: Vec<String> = habits
                .iter()
                .take(5)
                .map(|h| {
                    format!(
                        "- {} (seen {} times, last: {})",
                        h.context, h.frequency, h.last_seen
                    )
                })
                .collect();

            if top.is_empty() {
                "No established habits yet.".to_string()
            } else {
                format!("Learned habits:\n{}", top.join("\n"))
            }
        } else {
            String::new()
        }
    }

    pub fn get_top_habits_for_time(&self, current_hour: &str) -> Vec<String> {
        if let Ok(habits) = self.habits.lock() {
            habits
                .iter()
                .filter(|h| h.pattern.contains(&format!("_at_{}", current_hour)))
                .take(3)
                .map(|h| h.context.clone())
                .collect()
        } else {
            vec![]
        }
    }

    // ── Intent Patterns (for learning recurring request types) ──

    pub fn get_common_intents(&self) -> Vec<(String, u32)> {
        if let Ok(entries) = self.entries.lock() {
            let mut counts: HashMap<String, u32> = HashMap::new();
            for entry in entries.iter() {
                *counts.entry(entry.intent.clone()).or_insert(0) += 1;
            }
            let mut sorted: Vec<(String, u32)> = counts.into_iter().collect();
            sorted.sort_by(|a, b| b.1.cmp(&a.1));
            sorted.truncate(5);
            sorted
        } else {
            vec![]
        }
    }

    pub fn clear(&self) {
        if let Ok(mut entries) = self.entries.lock() {
            entries.clear();
            let _ = fs::write(&self.db_path, "[]");
        }
        if let Ok(mut habits) = self.habits.lock() {
            habits.clear();
            let _ = fs::write(&self.habits_path, "[]");
        }
    }
}

#[tauri::command]
pub fn get_history(memory: State<'_, MemoryStore>) -> Vec<String> {
    memory.get_recent(50)
}

#[tauri::command]
pub fn get_habits(memory: State<'_, MemoryStore>) -> String {
    memory.get_habits_summary()
}

#[tauri::command]
pub fn clear_history(memory: State<'_, MemoryStore>) -> String {
    memory.clear();
    "History and habits cleared".to_string()
}
