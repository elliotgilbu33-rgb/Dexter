pub mod commands;
pub mod ai;
pub mod memory;
pub mod config;

use tauri::Manager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_process::init())
        .plugin(tauri_plugin_global_shortcut::Builder::new().build())
        .plugin(tauri_plugin_notification::init())
        .setup(|app| {
            let handle = app.handle().clone();

            // Initialize memory store
            let store = memory::store::MemoryStore::new(app.path().app_data_dir().ok());
            app.manage(store);

            // Initialize config
            let cfg = config::ConfigState::new();
            app.manage(cfg);

            // Start AI pipeline watcher
            let ai_handle = handle.clone();
            tauri::async_runtime::spawn(async move {
                ai::pipeline::start_pipeline(ai_handle).await;
            });

            // System tray
            #[cfg(desktop)]
            {
                use tauri::tray::{TrayIconBuilder, MouseButton, MouseButtonState};
                use tauri::menu::{Menu, MenuItem};

                let show_item = MenuItem::with_id(app, "show", "Show Dexter", true, None::<&str>).unwrap();
                let toggle_item = MenuItem::with_id(app, "toggle_listen", "Toggle Listening", true, None::<&str>).unwrap();
                let settings_item = MenuItem::with_id(app, "settings", "Settings", true, None::<&str>).unwrap();
                let quit_item = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>).unwrap();

                let menu = Menu::with_items(app, &[&show_item, &toggle_item, &settings_item, &quit_item]).unwrap();

                let _tray = TrayIconBuilder::new()
                    .icon(app.default_window_icon().unwrap().clone())
                    .menu(&menu)
                    .on_menu_event(move |app, event| {
                        match event.id.as_ref() {
                            "show" => {
                                if let Some(window) = app.get_webview_window("overlay") {
                                    let _ = window.show();
                                    let _ = window.set_focus();
                                }
                            }
                            "toggle_listen" => {
                                let _ = app.emit("toggle-listening", ());
                            }
                            "settings" => {
                                if let Some(window) = app.get_webview_window("chat") {
                                    let _ = window.show();
                                    let _ = window.set_focus();
                                }
                            }
                            "quit" => {
                                app.exit(0);
                            }
                            _ => {}
                        }
                    })
                    .on_tray_icon_event(|tray, event| {
                        if let tauri::tray::TrayIconEvent::Click {
                            button: MouseButton::Left,
                            button_state: MouseButtonState::Up,
                            ..
                        } = event
                        {
                            let app = tray.app_handle();
                            if let Some(window) = app.get_webview_window("overlay") {
                                let _ = window.show();
                                let _ = window.set_focus();
                            }
                        }
                    })
                    .build(app)
                    .unwrap();
            }

            // Register global hotkey (Ctrl+Shift+D to toggle)
            #[cfg(desktop)]
            {
                use tauri_plugin_global_shortcut::GlobalShortcutExt;
                let shortcut_handle = app.handle().clone();
                app.global_shortcut().register("Ctrl+Shift+D", move || {
                    let _ = shortcut_handle.emit("toggle-overlay", ());
                }).unwrap();
            }

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::system::launch_app,
            commands::system::close_app,
            commands::system::list_running_apps,
            commands::system::open_url,
            commands::system::open_tabs,
            commands::system::web_search,
            commands::files::search_files,
            commands::files::open_folder,
            commands::windows::focus_window,
            commands::windows::get_open_windows,
            commands::windows::get_active_window,
            commands::windows::get_active_process,
            commands::windows::minimize_all,
            commands::windows::group_windows,
            commands::media::set_volume,
            commands::media::get_volume,
            commands::media::media_play_pause,
            commands::media::media_next,
            commands::media::media_prev,
            commands::monitor::get_system_info,
            commands::overlay::toggle_overlay,
            commands::overlay::set_overlay_always_on_top,
            ai::pipeline::send_message,
            memory::store::get_history,
            memory::store::get_habits,
            memory::store::clear_history,
            config::get_config,
            config::update_config,
        ])
        .run(tauri::generate_context!())
        .expect("error while running Dexter AI");
}
