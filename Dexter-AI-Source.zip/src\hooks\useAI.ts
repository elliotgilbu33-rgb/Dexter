import { useState, useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";

interface Message {
  role: "user" | "dexter";
  text: string;
}

export function useAI() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [thinking, setThinking] = useState(false);

  const send = useCallback(async (text: string) => {
    if (!text.trim()) return;

    setMessages((prev) => [...prev, { role: "user", text }]);
    setThinking(true);

    try {
      const result: any = await invoke("send_message", { text });
      setMessages((prev) => [...prev, { role: "dexter", text: result.speech }]);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        { role: "dexter", text: `Error: ${e.toString()}` },
      ]);
    }

    setThinking(false);
  }, []);

  const clear = useCallback(() => {
    setMessages([]);
    invoke("clear_history").catch(() => {});
  }, []);

  return { messages, thinking, send, clear };
}
