"""
Dexter AI — Setup Wizard
Downloads and configures all local AI components:
1. Ollama (local LLM server)
2. whisper.cpp (speech-to-text)
3. Piper TTS (text-to-speech)
"""

import os
import sys
import json
import urllib.request
import urllib.error
import subprocess
import zipfile
import tarfile
import shutil
import tempfile
import ctypes
from pathlib import Path

DEXTER_DIR = Path(os.environ.get("APPDATA", ".")) / "DexterAI"
MODELS_DIR = DEXTER_DIR / "models"
WHISPER_DIR = DEXTER_DIR / "whisper"
PIPER_DIR = DEXTER_DIR / "piper"
OLLAMA_DIR = DEXTER_DIR / "ollama"

CONFIG_PATH = DEXTER_DIR / "config.json"

OLLAMA_URL = "https://github.com/ollama/ollama/releases/latest/download/OllamaSetup.exe"
WHISPER_RELEASE_URL = "https://github.com/ggerganov/whisper.cpp/releases/latest/download/whisper-bin-x64.zip"
WHISPER_MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin"
PIPER_RELEASE_URL = "https://github.com/rhasspy/piper/releases/latest/download/piper_windows_amd64.zip"
PIPER_VOICE_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/ryan/medium/en_US-ryan-medium.onnx"
PIPER_VOICE_JSON_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/ryan/medium/en_US-ryan-medium.onnx.json"

OLLAMA_MODEL = "qwen2.5:3b"


def log(msg: str):
    print(f"[Dexter Setup] {msg}")


def download_file(url: str, dest: Path, desc: str = "") -> bool:
    try:
        log(f"Downloading {desc or dest.name}...")
        urllib.request.urlretrieve(url, dest)
        return True
    except Exception as e:
        log(f"Failed to download {desc or dest.name}: {e}")
        return False


def install_ollama():
    """Download and install Ollama silently."""
    log("Step 1/4: Setting up Ollama (local AI engine)...")
    OLLAMA_DIR.mkdir(parents=True, exist_ok=True)
    installer = OLLAMA_DIR / "OllamaSetup.exe"

    if download_file(OLLAMA_URL, installer, "Ollama installer"):
        log("Installing Ollama (this may take a moment)...")
        subprocess.run([str(installer), "/S"], capture_output=True)
        log("Ollama installed! Pulling default model...")
        subprocess.run(["ollama", "pull", OLLAMA_MODEL], capture_output=True)
        return True

    log("Ollama download failed. Please install manually from https://ollama.com")
    return False


def install_whisper():
    """Download whisper.cpp binaries and a model."""
    log("Step 2/4: Setting up Whisper (speech-to-text)...")
    WHISPER_DIR.mkdir(parents=True, exist_ok=True)
    whisper_zip = WHISPER_DIR / "whisper.zip"

    if download_file(WHISPER_RELEASE_URL, whisper_zip, "whisper.cpp binaries"):
        with zipfile.ZipFile(whisper_zip, "r") as zf:
            zf.extractall(WHISPER_DIR)
        whisper_zip.unlink()
        log("whisper.cpp binaries extracted")

    # Download model
    model_path = WHISPER_DIR / "ggml-tiny.en.bin"
    if not model_path.exists():
        download_file(WHISPER_MODEL_URL, model_path, "Whisper model (tiny.en)")
    else:
        log("Whisper model already exists")

    return True


def install_piper():
    """Download Piper TTS and a voice model."""
    log("Step 3/4: Setting up Piper (text-to-speech)...")
    PIPER_DIR.mkdir(parents=True, exist_ok=True)

    # Try to auto-detect the piper exe
    piper_exe = PIPER_DIR / "piper.exe"
    if not piper_exe.exists():
        piper_zip = PIPER_DIR / "piper.zip"
        if download_file(PIPER_RELEASE_URL, piper_zip, "Piper TTS"):
            with zipfile.ZipFile(piper_zip, "r") as zf:
                zf.extractall(PIPER_DIR)
            piper_zip.unlink()
            # Find the exe (might be in a subdirectory)
            for f in PIPER_DIR.rglob("piper.exe"):
                shutil.move(str(f), str(piper_exe))
                break
            log("Piper extracted")

    # Download voice model
    voice_path = PIPER_DIR / "en_US-ryan-medium.onnx"
    if not voice_path.exists():
        download_file(PIPER_VOICE_URL, voice_path, "Ryan voice model")
        download_file(PIPER_VOICE_JSON_URL, voice_path.with_suffix(".onnx.json"), "Ryan voice config")
    else:
        log("Voice model already exists")

    return True


def write_config():
    """Write initial Dexter config."""
    config = {
        "llm_model": OLLAMA_MODEL,
        "voice": "en_US-ryan-medium",
        "wake_word_enabled": True,
        "always_on": False,
        "auto_start": True,
        "volume": 0.5,
        "whisper_path": str(WHISPER_DIR),
        "piper_path": str(PIPER_DIR),
        "setup_complete": True,
    }
    DEXTER_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)
    log(f"Configuration saved to {CONFIG_PATH}")


def add_auto_start():
    """Add Dexter to Windows startup."""
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE
        )
        dexter_exe = Path(sys.argv[0]).resolve()
        winreg.SetValueEx(key, "DexterAI", 0, winreg.REG_SZ, str(dexter_exe))
        winreg.CloseKey(key)
        log("Added Dexter to startup programs")
    except Exception as e:
        log(f"Could not add to startup: {e}")


def main():
    log("=" * 50)
    log("DEXTER AI — Setup Wizard")
    log("This will download ~3GB of AI models and tools.")
    log("Make sure you have a stable internet connection.")
    log("=" * 50)

    DEXTER_DIR.mkdir(parents=True, exist_ok=True)

    install_ollama()
    install_whisper()
    install_piper()

    log("Step 4/4: Finalizing configuration...")
    write_config()
    add_auto_start()

    log("=" * 50)
    log("SETUP COMPLETE! ✓")
    log("Dexter AI is ready to use.")
    log("Say 'Hey Dexter' to activate, or press Ctrl+Shift+D.")
    log("=" * 50)


if __name__ == "__main__":
    main()
