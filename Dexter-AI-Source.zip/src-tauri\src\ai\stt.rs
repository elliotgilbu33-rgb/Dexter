use serde_json::json;
use std::process::Command as StdCommand;

pub struct STTClient {
    server_url: String,
}

impl STTClient {
    pub fn new() -> Self {
        STTClient {
            server_url: "http://127.0.0.1:9000".to_string(),
        }
    }

    pub fn transcribe(&self, audio_path: &str) -> Result<String, String> {
        let output = StdCommand::new("whisper.cpp/build/bin/whisper-cli")
            .args([
                "-f", audio_path,
                "-m", "whisper.cpp/models/ggml-tiny.en.bin",
                "-otxt",
                "-nt",
            ])
            .output()
            .map_err(|e| format!("Whisper failed: {}", e))?;

        let text = String::from_utf8_lossy(&output.stdout).trim().to_string();
        Ok(text)
    }

    pub fn set_server_url(&mut self, url: String) {
        self.server_url = url;
    }
}
