use tauri::command;
use sysinfo::{System, SystemExt, CpuExt, DiskExt};
use serde::Serialize;

#[derive(Serialize)]
pub struct SystemInfo {
    pub cpu_usage: f32,
    pub memory_used: u64,
    pub memory_total: u64,
    pub memory_percent: f32,
    pub disk_used: u64,
    pub disk_total: u64,
    pub uptime: u64,
    pub processes: u32,
}

#[command]
pub fn get_system_info() -> SystemInfo {
    let mut sys = System::new_all();
    sys.refresh_all();

    let cpu_usage = sys.global_cpu_info().cpu_usage();
    let memory_used = sys.used_memory();
    let memory_total = sys.total_memory();
    let memory_percent = if memory_total > 0 {
        (memory_used as f32 / memory_total as f32) * 100.0
    } else {
        0.0
    };

    let disk = sys.disks().first();
    let (disk_used, disk_total) = match disk {
        Some(d) => {
            let total = d.total_space();
            let available = d.available_space();
            (total - available, total)
        }
        None => (0, 0),
    };

    SystemInfo {
        cpu_usage,
        memory_used,
        memory_total,
        memory_percent,
        disk_used,
        disk_total,
        uptime: sys.uptime(),
        processes: sys.processes().len() as u32,
    }
}
