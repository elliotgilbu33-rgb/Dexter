#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    dexter_ai_lib::run()
}
