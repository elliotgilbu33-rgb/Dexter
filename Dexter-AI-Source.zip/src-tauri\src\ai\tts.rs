use std::process::Command as StdCommand;
use std::fs;
use std::path::Path;

pub struct TTSClient {
    piper_path: String,
    voice_model: String,
    output_dir: String,
}

impl TTSClient {
    pub fn new() -> Self {
        let app_data = dirs::data_dir()
            .unwrap_or_else(|| Path::new(".").to_path_buf())
            .join("DexterAI");

        TTSClient {
            piper_path: app_data
                .join("piper")
                .join("piper.exe")
                .to_string_lossy()
                .to_string(),
            voice_model: app_data
                .join("piper")
                .join("en_US-ryan-medium.onnx")
                .to_string_lossy()
                .to_string(),
            output_dir: app_data
                .join("piper")
                .join("output")
                .to_string_lossy()
                .to_string(),
        }
    }

    pub fn speak(&self, text: &str) -> Result<String, String> {
        fs::create_dir_all(&self.output_dir).map_err(|e| e.to_string())?;

        let output_file = format!("{}\\speak.wav", self.output_dir);

        let result = StdCommand::new(&self.piper_path)
            .args([
                "--model",
                &self.voice_model,
                "--output-raw",
                "--output-file",
                &output_file,
            ])
            .stdin(std::process::Stdio::piped())
            .spawn();

        match result {
            Ok(mut child) => {
                use std::io::Write;
                if let Some(ref mut stdin) = child.stdin {
                    let _ = stdin.write_all(text.as_bytes());
                }
                let _ = child.wait();
                // Play the audio
                let _ = StdCommand::new("powershell")
                    .args([
                        "-Command",
                        &format!(
                            "(New-Object Media.SoundPlayer '{}').PlaySync()",
                            output_file
                        ),
                    ])
                    .output();
                Ok("Spoke successfully".to_string())
            }
            Err(e) => Err(format!("Piper TTS failed: {}", e)),
        }
    }
}
