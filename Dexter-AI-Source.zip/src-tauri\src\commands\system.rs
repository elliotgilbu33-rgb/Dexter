use tauri::command;
use std::process::Command as StdCommand;

#[command]
pub fn launch_app(app_name: String) -> Result<String, String> {
    let result = StdCommand::new("cmd")
        .args(["/C", "start", "", &app_name])
        .spawn();

    match result {
        Ok(_) => Ok(format!("Launched {}", app_name)),
        Err(e) => Err(format!("Failed to launch {}: {}", app_name, e)),
    }
}

#[command]
pub fn close_app(app_name: String) -> Result<String, String> {
    let result = StdCommand::new("taskkill")
        .args(["/IM", &format!("{}.exe", app_name), "/F"])
        .output();

    match result {
        Ok(output) => {
            let stdout = String::from_utf8_lossy(&output.stdout);
            Ok(format!("Closed {}: {}", app_name, stdout.trim()))
        }
        Err(e) => Err(format!("Failed to close {}: {}", app_name, e)),
    }
}

#[command]
pub fn list_running_apps() -> Result<Vec<String>, String> {
    let output = StdCommand::new("tasklist")
        .args(["/FO", "CSV", "/NH"])
        .output()
        .map_err(|e| e.to_string())?;

    let stdout = String::from_utf8_lossy(&output.stdout);
    let apps: Vec<String> = stdout
        .lines()
        .filter_map(|line| {
            let parts: Vec<&str> = line.split(',').collect();
            if parts.len() >= 1 {
                Some(parts[0].trim_matches('"').to_string())
            } else {
                None
            }
        })
        .take(50)
        .collect();

    Ok(apps)
}

#[command]
pub fn open_url(url: String) -> Result<String, String> {
    let result = StdCommand::new("cmd")
        .args(["/C", "start", "", &url])
        .spawn();

    match result {
        Ok(_) => Ok(format!("Opened {}", url)),
        Err(e) => Err(format!("Failed to open URL: {}", e)),
    }
}

#[command]
pub fn open_tabs(urls: Vec<String>) -> Result<String, String> {
    let browser = detect_default_browser();
    let mut results = Vec::new();

    for url in &urls {
        let result = StdCommand::new("cmd")
            .args(["/C", "start", "", url])
            .spawn();

        match result {
            Ok(_) => results.push(format!("Opened {}", url)),
            Err(e) => results.push(format!("Failed: {}", e)),
        }
        // Small delay between tab opens
        std::thread::sleep(std::time::Duration::from_millis(300));
    }

    Ok(results.join("; "))
}

#[command]
pub fn web_search(query: String) -> Result<String, String> {
    let encoded: String = query
        .chars()
        .map(|c| match c {
            ' ' => '+'.to_string(),
            c if c.is_alphanumeric() || c == '-' || c == '_' => c.to_string(),
            c => c.to_string(),
        })
        .collect();

    let url = format!("https://www.google.com/search?q={}", encoded);
    let result = StdCommand::new("cmd")
        .args(["/C", "start", "", &url])
        .spawn();

    match result {
        Ok(_) => Ok(format!("Searched for: {}", query)),
        Err(e) => Err(format!("Failed to search: {}", e)),
    }
}

fn detect_default_browser() -> String {
    // Read default browser from registry
    let output = StdCommand::new("powershell")
        .args([
            "-Command",
            "(Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\Shell\\Associations\\UrlAssociations\\http\\UserChoice').ProgId",
        ])
        .output()
        .ok();

    match output {
        Some(out) => {
            let stdout = String::from_utf8_lossy(&out.stdout);
            let prog_id = stdout.trim();
            if prog_id.contains("Chrome") || prog_id.contains("ChromeHTML") {
                "chrome".to_string()
            } else if prog_id.contains("Firefox") || prog_id.contains("FirefoxURL") {
                "firefox".to_string()
            } else if prog_id.contains("Edge") || prog_id.contains("MSEdge") {
                "edge".to_string()
            } else if prog_id.contains("Opera") {
                "opera".to_string()
            } else {
                "default".to_string()
            }
        }
        None => "default".to_string(),
    }
}
