import { useState, useEffect, useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import Orb from "./components/Orb";
import Waveform from "./components/Waveform";
import VoiceIndicator from "./components/VoiceIndicator";
import ChatPanel from "./components/ChatPanel";
import Settings from "./components/Settings";

type View = "overlay" | "chat" | "settings";

interface Message {
  role: "user" | "dexter";
  text: string;
  intent?: string;
  confidence?: number;
  reasoning?: string;
  suggestions?: string[];
}

interface DexterResult {
  text: string;
  intent: string;
  confidence: number;
  reasoning: string;
  actions: Array<{ action: string; params: Record<string, string>; result: string; success: boolean }>;
  speech: string;
  suggestions: string[];
}

function App() {
  const [view, setView] = useState<View>("overlay");
  const [listening, setListening] = useState(true);
  const [speaking, setSpeaking] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [systemInfo, setSystemInfo] = useState({ cpu: 0, ram: 0 });
  const [inputText, setInputText] = useState("");

  useEffect(() => {
    const unlisten1 = listen("toggle-listening", () => {
      setListening((l) => !l);
    });
    const unlisten2 = listen("toggle-overlay", () => {
      setView((v) => (v === "overlay" ? "chat" : "overlay"));
    });

    return () => {
      unlisten1.then((f) => f());
      unlisten2.then((f) => f());
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const info: any = await invoke("get_system_info");
        setSystemInfo({ cpu: info.cpu_usage, ram: info.memory_percent });
      } catch {}
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = { role: "user", text };
    setMessages((prev) => [...prev, userMessage]);
    setThinking(true);
    setSpeaking(false);

    try {
      const result: DexterResult = await invoke("send_message", { text });

      const dexterMessage: Message = {
        role: "dexter",
        text: result.speech,
        intent: result.intent,
        confidence: result.confidence,
        reasoning: result.reasoning,
        suggestions: result.suggestions,
      };

      setMessages((prev) => [...prev, dexterMessage]);

      if (result.speech) {
        setSpeaking(true);
        setTimeout(() => setSpeaking(false), Math.min(result.speech.length * 60, 8000));
      }
    } catch (e) {
      setMessages((prev) => [
        ...prev,
        { role: "dexter", text: `Error: ${e}` },
      ]);
    }
    setThinking(false);
  }, []);

  const handleVoiceInput = useCallback(
    async (transcribedText: string) => {
      if (transcribedText.trim()) {
        await sendMessage(transcribedText);
      }
    },
    [sendMessage]
  );

  if (view === "overlay") {
    return (
      <div className="w-screen h-screen drag-region relative">
        <div
          className="absolute inset-0 flex flex-col items-center justify-center cursor-default"
          onDoubleClick={() => setView("chat")}
        >
          <Orb
            listening={listening}
            speaking={speaking}
            thinking={thinking}
            onClick={() => setView("chat")}
          />
          <div className="mt-2 flex items-center gap-3">
            <Waveform active={listening} />
            <VoiceIndicator
              listening={listening}
              speaking={speaking}
              thinking={thinking}
            />
          </div>
          <div className="mt-1 text-[10px] text-dexter-dim tracking-wider uppercase">
            CPU {systemInfo.cpu.toFixed(0)}% &nbsp;·&nbsp; RAM{" "}
            {systemInfo.ram.toFixed(0)}%
          </div>
        </div>
        <div className="absolute top-1 right-2 no-drag">
          <button
            onClick={() => setView("settings")}
            className="text-dexter-dim hover:text-dexter-cyan text-xs p-1 transition-colors"
            title="Settings"
          >
            ⚙
          </button>
        </div>
      </div>
    );
  }

  if (view === "settings") {
    return (
      <div className="w-screen h-screen bg-dexter-bg flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-dexter-border">
          <h1 className="text-lg font-semibold neon-text">Dexter Settings</h1>
          <button
            onClick={() => setView("chat")}
            className="text-dexter-dim hover:text-dexter-cyan text-sm transition-colors"
          >
            ← Back
          </button>
        </div>
        <Settings onClose={() => setView("chat")} />
      </div>
    );
  }

  return (
    <div className="w-screen h-screen bg-dexter-bg flex flex-col">
      <div className="flex items-center justify-between p-4 border-b border-dexter-border">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 rounded-full bg-dexter-cyan shadow-glow" />
          <h1 className="text-lg font-semibold neon-text">Dexter AI</h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setListening(!listening)}
            className={`px-3 py-1 text-xs rounded-full border transition-all ${
              listening
                ? "border-dexter-cyan text-dexter-cyan bg-dexter-cyan/10"
                : "border-dexter-dim/30 text-dexter-dim"
            }`}
          >
            {listening ? "Listening" : "Muted"}
          </button>
          <button
            onClick={() => setView("settings")}
            className="text-dexter-dim hover:text-dexter-cyan text-sm p-1 transition-colors"
          >
            ⚙
          </button>
        </div>
      </div>

      <ChatPanel
        messages={messages}
        thinking={thinking}
        onSend={sendMessage}
        inputText={inputText}
        onInputChange={setInputText}
      />

      <div className="p-3 border-t border-dexter-border">
        <div className="flex items-center gap-2 glass rounded-xl px-4 py-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage(inputText);
                setInputText("");
              }
            }}
            placeholder={thinking ? "Thinking..." : "Ask Dexter anything..."}
            disabled={thinking}
            className="flex-1 bg-transparent text-sm outline-none text-dexter-white placeholder-dexter-dim/50"
          />
          <button
            onClick={() => {
              sendMessage(inputText);
              setInputText("");
            }}
            disabled={thinking || !inputText.trim()}
            className="no-drag text-dexter-cyan hover:text-dexter-white disabled:text-dexter-dim/30 transition-colors"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 2L11 13" /><path d="M22 2L15 22L11 13L2 9L22 2Z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
