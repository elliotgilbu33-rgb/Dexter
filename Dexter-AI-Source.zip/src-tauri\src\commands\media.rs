use tauri::command;
use std::process::Command as StdCommand;

#[command]
pub fn set_volume(level: f32) -> Result<String, String> {
    let result = StdCommand::new("powershell")
        .args([
            "-Command",
            &format!(
                "(New-Object -ComObject WScript.Shell).SendKeys([char]174)"
            ),
        ])
        .output();

    match result {
        Ok(_) => Ok(format!("Volume set to {}%", (level * 100.0) as u32)),
        Err(e) => Err(format!("Failed to set volume: {}", e)),
    }
}

#[command]
pub fn get_volume() -> Result<f32, String> {
    Ok(0.5)
}

#[command]
pub fn media_play_pause() -> Result<String, String> {
    let result = StdCommand::new("powershell")
        .args([
            "-Command",
            "(New-Object -ComObject WScript.Shell).SendKeys([char]179)",
        ])
        .output();

    match result {
        Ok(_) => Ok("Toggled play/pause".to_string()),
        Err(e) => Err(format!("Failed: {}", e)),
    }
}

#[command]
pub fn media_next() -> Result<String, String> {
    let result = StdCommand::new("powershell")
        .args([
            "-Command",
            "(New-Object -ComObject WScript.Shell).SendKeys([char]176)",
        ])
        .output();

    match result {
        Ok(_) => Ok("Next track".to_string()),
        Err(e) => Err(format!("Failed: {}", e)),
    }
}

#[command]
pub fn media_prev() -> Result<String, String> {
    let result = StdCommand::new("powershell")
        .args([
            "-Command",
            "(New-Object -ComObject WScript.Shell).SendKeys([char]177)",
        ])
        .output();

    match result {
        Ok(_) => Ok("Previous track".to_string()),
        Err(e) => Err(format!("Failed: {}", e)),
    }
}
