use tauri::{command, Manager};

#[command]
pub fn toggle_overlay(app: tauri::AppHandle) -> Result<String, String> {
    if let Some(window) = app.get_webview_window("overlay") {
        if window.is_visible().unwrap_or(false) {
            let _ = window.hide();
            Ok("Overlay hidden".to_string())
        } else {
            let _ = window.show();
            let _ = window.set_focus();
            Ok("Overlay shown".to_string())
        }
    } else {
        Err("Overlay window not found".to_string())
    }
}

#[command]
pub fn set_overlay_always_on_top(app: tauri::AppHandle, enabled: bool) -> Result<String, String> {
    if let Some(window) = app.get_webview_window("overlay") {
        let _ = window.set_always_on_top(enabled);
        Ok(format!("Overlay always-on-top set to {}", enabled))
    } else {
        Err("Overlay window not found".to_string())
    }
}
