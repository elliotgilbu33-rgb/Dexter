use tauri::command;
use std::process::Command as StdCommand;

#[command]
pub fn focus_window(window_title: String) -> Result<String, String> {
    let result = StdCommand::new("powershell")
        .args([
            "-Command",
            &format!(
                "$wshell = New-Object -ComObject wscript.shell; $wshell.AppActivate('{}')",
                window_title
            ),
        ])
        .output();

    match result {
        Ok(_) => Ok(format!("Focused on {}", window_title)),
        Err(e) => Err(format!("Failed to focus {}: {}", window_title, e)),
    }
}

#[command]
pub fn get_open_windows() -> Result<Vec<String>, String> {
    let output = StdCommand::new("powershell")
        .args([
            "-Command",
            "(Get-Process | Where-Object { $_.MainWindowTitle -ne '' } | Select-Object -ExpandProperty MainWindowTitle | Select-Object -Unique -First 30) -join '`n'",
        ])
        .output()
        .map_err(|e| e.to_string())?;

    let stdout = String::from_utf8_lossy(&output.stdout);
    let windows: Vec<String> = stdout
        .lines()
        .filter(|l| !l.is_empty())
        .map(|l| l.to_string())
        .collect();

    Ok(windows)
}

#[command]
pub fn get_active_window() -> Result<String, String> {
    let output = StdCommand::new("powershell")
        .args([
            "-Command",
            "Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Diagnostics;
public class ActiveWin {
    [DllImport(\"user32.dll\")] static extern IntPtr GetForegroundWindow();
    [DllImport(\"user32.dll\")] static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    public static string Get() {
        IntPtr hwnd = GetForegroundWindow();
        StringBuilder sb = new StringBuilder(256);
        GetWindowText(hwnd, sb, 256);
        return sb.ToString();
    }
}
'@; [ActiveWin]::Get()",
        ])
        .output()
        .map_err(|e| e.to_string())?;

    let stdout = String::from_utf8_lossy(&output.stdout);
    Ok(stdout.trim().to_string())
}

#[command]
pub fn get_active_process() -> Result<String, String> {
    let output = StdCommand::new("powershell")
        .args([
            "-Command",
            "(Get-Process | Where-Object { $_.MainWindowHandle -eq (Add-Type @'
using System;
using System.Runtime.InteropServices;
public class Win {
    [DllImport(\"user32.dll\")] static extern IntPtr GetForegroundWindow();
    public static IntPtr Get() { return GetForegroundWindow(); }
}
'@ -PassThru; [Win]::Get()) } | Select-Object -First 1 -ExpandProperty ProcessName) -join ''",
        ])
        .output()
        .map_err(|e| e.to_string())?;

    let stdout = String::from_utf8_lossy(&output.stdout);
    let trimmed = stdout.trim().trim_end_matches(".exe").to_string();
    Ok(if trimmed.is_empty() { "unknown".to_string() } else { trimmed })
}

#[command]
pub fn minimize_all() -> Result<String, String> {
    let result = StdCommand::new("powershell")
        .args([
            "-Command",
            "(New-Object -ComObject Shell.Application).MinimizeAll()",
        ])
        .output();

    match result {
        Ok(_) => Ok("All windows minimized".to_string()),
        Err(e) => Err(format!("Failed to minimize: {}", e)),
    }
}

#[command]
pub fn group_windows() -> Result<String, String> {
    // Resize and arrange windows (simple approach: minimize all non-essential)
    let result = StdCommand::new("powershell")
        .args([
            "-Command",
            "$shell = New-Object -ComObject Shell.Application; $shell.MinimizeAll(); Start-Sleep -Milliseconds 500; $shell.UndoMinimizeAll()",
        ])
        .output();

    match result {
        Ok(_) => Ok("Windows regrouped".to_string()),
        Err(e) => Err(format!("Failed to group windows: {}", e)),
    }
}
