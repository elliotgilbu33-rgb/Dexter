interface WaveformProps {
  active: boolean;
}

export default function Waveform({ active }: WaveformProps) {
  if (!active) return null;

  const bars = [1, 2, 3, 4, 5, 4, 3, 2];

  return (
    <div className="flex items-center gap-[2px] h-4">
      {bars.map((h, i) => (
        <div
          key={i}
          className="w-[2px] rounded-full bg-dexter-cyan/70"
          style={{
            height: `${h * 3}px`,
            animationDuration: `${0.4 + Math.random() * 0.3}s`,
            animationDelay: `${i * 0.06}s`,
          }}
        >
          <style>{`
            @keyframes wave-${i} {
              0%, 100% { height: 4px; opacity: 0.4; }
              50% { height: ${h * 3 + 4}px; opacity: 1; }
            }
          `}</style>
          <div
            className="w-full rounded-full bg-dexter-cyan"
            style={{
              height: "100%",
              animation: `wave-${i} ${0.4 + Math.random() * 0.3}s ease-in-out infinite`,
              animationDelay: `${i * 0.06}s`,
            }}
          />
        </div>
      ))}
    </div>
  );
}
