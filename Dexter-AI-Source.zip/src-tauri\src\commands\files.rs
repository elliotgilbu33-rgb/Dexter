use tauri::command;
use std::process::Command as StdCommand;

#[command]
pub fn search_files(query: String) -> Result<Vec<String>, String> {
    let output = StdCommand::new("powershell")
        .args([
            "-Command",
            &format!(
                "Get-ChildItem -Path $env:USERPROFILE -Recurse -Filter '*{}*' -ErrorAction SilentlyContinue | Select-Object -First 20 | Select-Object -ExpandProperty FullName",
                query
            ),
        ])
        .output()
        .map_err(|e| e.to_string())?;

    let stdout = String::from_utf8_lossy(&output.stdout);
    let files: Vec<String> = stdout
        .lines()
        .filter(|l| !l.is_empty())
        .map(|l| l.to_string())
        .collect();

    Ok(files)
}

#[command]
pub fn open_folder(path: String) -> Result<String, String> {
    let result = StdCommand::new("explorer")
        .arg(&path)
        .spawn();

    match result {
        Ok(_) => Ok(format!("Opened {}", path)),
        Err(e) => Err(format!("Failed to open {}: {}", path, e)),
    }
}
