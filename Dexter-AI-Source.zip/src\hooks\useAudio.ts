import { useState, useRef, useCallback } from "react";

export function useAudio() {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState("");
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
      chunks.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.current.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks.current, { type: "audio/webm" });
        // Send to Whisper server via fetch
        sendToWhisper(blob).then(setTranscript).catch(console.error);
        stream.getTracks().forEach((t) => t.stop());
      };

      recorder.start();
      mediaRecorder.current = recorder;
      setIsRecording(true);
    } catch (err) {
      console.error("Microphone access denied:", err);
      setIsRecording(false);
    }
  }, []);

  const stopRecording = useCallback(() => {
    if (mediaRecorder.current && mediaRecorder.current.state === "recording") {
      mediaRecorder.current.stop();
      setIsRecording(false);
    }
  }, []);

  const sendToWhisper = async (audio: Blob): Promise<string> => {
    try {
      const formData = new FormData();
      formData.append("file", audio, "audio.webm");
      const res = await fetch("http://127.0.0.1:9000/inference", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      return data.text || "";
    } catch {
      return "";
    }
  };

  return { isRecording, transcript, startRecording, stopRecording };
}
