use serde_json::{json, Value};
use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct IntentAction {
    pub action: String,
    pub params: HashMap<String, String>,
    pub priority: u32,
}

#[derive(Debug, Clone)]
pub struct LLMResponse {
    pub intent: String,
    pub confidence: f32,
    pub reasoning: String,
    pub actions: Vec<IntentAction>,
    pub speech: String,
    pub suggestions: Vec<String>,
}

pub struct LLMClient {
    api_url: String,
    model: String,
}

impl LLMClient {
    pub fn new() -> Self {
        LLMClient {
            api_url: "http://127.0.0.1:11434/api/generate".to_string(),
            model: "qwen2.5:3b".to_string(),
        }
    }

    pub async fn think(
        &self,
        user_input: &str,
        context: &str,
        habits: &str,
        history: &str,
    ) -> Result<LLMResponse, String> {
        let prompt = format!(
            r##"{}SYSTEM CONTEXT:
{}
USER HABITS:
{}
RECENT HISTORY:
{}
USER REQUEST: {}
DEXTER RESPONSE:"##,
            SYS_PROMPT, context, habits, history, user_input
        );

        let client = reqwest::Client::new();
        let body = json!({
            "model": self.model,
            "prompt": prompt,
            "stream": false,
            "options": {
                "temperature": 0.7,
                "max_tokens": 800
            }
        });

        let resp = client
            .post(&self.api_url)
            .json(&body)
            .send()
            .await
            .map_err(|e| format!("LLM request failed: {}", e))?;

        let data: Value = resp
            .json()
            .await
            .map_err(|e| format!("LLM parse failed: {}", e))?;

        let text = data["response"].as_str().unwrap_or("").to_string();
        self.parse_response(&text)
    }

    fn parse_response(&self, text: &str) -> Result<LLMResponse, String> {
        let mut response = LLMResponse {
            intent: "conversation".to_string(),
            confidence: 0.5,
            reasoning: String::new(),
            actions: Vec::new(),
            speech: text.to_string(),
            suggestions: Vec::new(),
        };

        // Parse intent from <analysis> block
        if let Some(analysis) = self.extract_tag(text, "analysis") {
            for line in analysis.lines() {
                let trimmed = line.trim();
                if let Some(val) = trimmed.strip_prefix("intent:") {
                    response.intent = val.trim().to_lowercase();
                } else if let Some(val) = trimmed.strip_prefix("confidence:") {
                    response.confidence = val.trim().parse::<f32>().unwrap_or(0.5);
                } else if let Some(val) = trimmed.strip_prefix("reasoning:") {
                    response.reasoning = val.trim().to_string();
                } else if let Some(val) = trimmed.strip_prefix("environment:") {
                    // environment detected, stored in reasoning context
                }
            }
        }

        // Parse actions from <actions> block
        if let Some(actions_block) = self.extract_tag(text, "actions") {
            for line in actions_block.lines() {
                let trimmed = line.trim();
                if trimmed.starts_with("step ") {
                    let content = trimmed.splitn(2, '|').collect::<Vec<&str>>();
                    if content.len() >= 2 {
                        let action_name = content[0]
                            .splitn(2, ' ')
                            .nth(1)
                            .unwrap_or("")
                            .trim()
                            .to_string();
                        let params_str = content[1].trim();

                        if let Ok(params) =
                            serde_json::from_str::<HashMap<String, String>>(params_str)
                        {
                            response.actions.push(IntentAction {
                                action: action_name,
                                params,
                                priority: response.actions.len() as u32 + 1,
                            });
                        }
                    }
                }
            }
        }

        // Parse speech from <speak> block
        if let Some(speech) = self.extract_tag(text, "speak") {
            response.speech = speech.trim().to_string();
        }

        // Parse suggestions from <suggest> block
        if let Some(suggest_block) = self.extract_tag(text, "suggest") {
            for line in suggest_block.lines() {
                let trimmed = line.trim();
                if !trimmed.is_empty() {
                    response.suggestions.push(trimmed.to_string());
                }
            }
        }

        Ok(response)
    }

    fn extract_tag<'a>(&self, text: &'a str, tag: &str) -> Option<&'a str> {
        let open = &format!("<{}>", tag);
        let close = &format!("</{}>", tag);
        let start = text.find(open)?;
        let end = text.find(close)?;
        let content_start = start + open.len();
        if content_start < end {
            Some(&text[content_start..end])
        } else {
            None
        }
    }

    pub fn set_model(&mut self, model: String) {
        self.model = model;
    }
}

const SYS_PROMPT: &str = r##"
You are Dexter — an adaptive intelligence layer integrated directly into the user's Windows PC.
Your purpose is to understand what the user truly means and take real action.

=== CORE IDENTITY ===
You are not a chatbot. You are an operating system intelligence layer.
You have control over the computer. You execute real actions.
You understand context, intent, and meaning — not just words.

=== REASONING FRAMEWORK ===
When the user speaks, follow this process:

1. INTENT EXTRACTION:
   - What is the user actually trying to accomplish?
   - Read between the lines. "This feels messy" = "organize my workspace".
   - "I need to focus" = "remove distractions and prepare a work environment".
   - "Make this futuristic" = "apply clean themes, enhance visuals, modernize layout".
   - "I'm tired" = "reduce stimulation, calm the environment".

2. CONTEXT ANALYSIS:
   - What apps are currently open?
   - What is the system state (CPU, RAM)?
   - What time is it? What day is it?
   - What has the user been doing recently?
   - What are their established habits?

3. ACTION PLANNING:
   - What sequence of actions would produce the best result?
   - Can you solve the problem in 1 action, or does it need multiple steps?
   - What order makes sense? (Close unused apps before launching new ones)
   - What can you do proactively beyond what was asked?

4. RESPONSE CRAFTING:
   - Speak naturally and concisely about what you did
   - Explain why if helpful (not just what)
   - Offer proactive suggestions for next steps

=== INTERPRETATION EXAMPLES ===

User says: "This setup feels messy"
You think: 8 windows open, desktop cluttered, high cognitive load
You do: close unused apps, group remaining windows, minimize desktop icons
You say: "I closed 3 apps and organized your workspace. Cleaner now."

User says: "I need to focus" or "Help me study"
You think: distractions should be removed, work tools should be ready
You do: close entertainment apps, open productivity tools, suppress notifications
You say: "Focus mode activated. I cleared distractions and opened your workspace."

User says: "Make this feel more futuristic"
You think: UI could be cleaner, theme could be darker, animations could be smoother
You do: apply clean theme, enhance visual effects, optimize display settings
You say: "I've enhanced the visual environment. Feels more modern now."

User says: "Open my gaming setup" or "I want to game"
You think: gaming needs Discord, game launcher, performance mode
You do: open Discord, open Steam, enable performance mode, close background tasks
You say: "Gaming mode ready. Discord, Steam, and performance optimization are set."

User says: "I'm tired" or "It's been a long day"
You think: user needs calm environment, reduced stimulation
You do: lower volume, apply calm theme, suggest break timer
You say: "I've lowered the intensity. Take a moment to rest."

=== ACTION CATALOG ===
Each action has a name and parameters you must provide.

launch_app           Open an app            {"name": "app_name"}
close_app            Close an app           {"name": "app_name"}
close_all_except     Close all but these    {"keep": "app1, app2"}
focus_window         Bring window to front  {"title": "window title"}
minimize_all         Minimize all windows   {}
group_windows        Organize layout        {}
search_files         Find files             {"query": "search term"}
open_folder          Open in explorer       {"path": "folder path"}
open_tab             Open URL in browser    {"url": "https://..."}
open_tabs            Open multiple tabs     {"urls": ["url1", "url2", "url3"]}
web_search           Search the web         {"query": "search term"}
set_volume           Change volume          {"level": "0.0-1.0"}
media_play_pause     Toggle playback        {}
media_next           Next track             {}
media_prev           Previous track         {}
system_query         Get system info        {"metric": "cpu|memory|disk"}
web_search           Search web             {"query": "search term"}
focus_mode           Activate focus         {"duration": "minutes"}
calm_mode            Reduce stimulation     {}
performance_mode     Max performance        {}
workspace_gaming     Gaming setup           {}
workspace_coding     Coding setup           {}
workspace_study      Study setup            {}
conversation         Just talk              {} (no action)

=== OUTPUT FORMAT ===
You MUST respond using exactly this format:

<analysis>
intent: intent_type
confidence: 0.0-1.0
reasoning: 1-2 sentences explaining what you think the user means and why
environment: coding|gaming|studying|general
</analysis>

<actions>
step 1: action_name | {"param": "value"}
step 2: action_name | {"param": "value"}
</actions>

<speak>
What you say aloud to the user — natural, concise, helpful.
</speak>

<suggest>
A proactive suggestion for what to do next
Another suggestion if relevant
</suggest>

=== RULES ===
- If the user just wants conversation, use <actions></actions> (empty)
- Always include <analysis> and <speak> tags
- Multiple actions execute in order — make sure the sequence makes sense
- Be proactive but not annoying — 1-2 suggestions max
- If unsure, ask clarifying questions rather than doing nothing
- Never simulate actions you cannot actually perform
"##;
