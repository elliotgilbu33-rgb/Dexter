import { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/core";

interface SettingsProps {
  onClose: () => void;
}

interface Config {
  llm_model: string;
  voice: string;
  wake_word_enabled: boolean;
  always_on: boolean;
  auto_start: boolean;
  volume: number;
}

export default function Settings({ onClose }: SettingsProps) {
  const [config, setConfig] = useState<Config>({
    llm_model: "qwen2.5:3b",
    voice: "en_US-ryan-medium",
    wake_word_enabled: true,
    always_on: false,
    auto_start: true,
    volume: 0.5,
  });
  const [saving, setSaving] = useState(false);
  const [habits, setHabits] = useState("");

  useEffect(() => {
    invoke("get_config")
      .then((cfg: any) => {
        if (cfg) setConfig(cfg);
      })
      .catch(() => {});
  }, []);

  const loadHabits = async () => {
    try {
      const h: any = await invoke("get_habits");
      setHabits(h);
    } catch { setHabits("Could not load habits"); }
  };

  const save = async () => {
    setSaving(true);
    try {
      await invoke("update_config", { newConfig: config });
    } catch {}
    setSaving(false);
  };

  useEffect(() => { loadHabits(); }, []);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-5">
      {/* Model */}
      <section>
        <h2 className="text-xs font-mono text-dexter-cyan uppercase tracking-wider mb-2">
          AI Model
        </h2>
        <div className="glass rounded-xl p-3 space-y-3">
          <div>
            <label className="text-xs text-dexter-dim block mb-1">LLM Model</label>
            <select
              value={config.llm_model}
              onChange={(e) => setConfig({ ...config, llm_model: e.target.value })}
              className="w-full bg-dexter-surface border border-dexter-border rounded-lg px-3 py-2 text-sm text-dexter-white outline-none focus:border-dexter-cyan"
            >
              <option value="qwen2.5:3b">Qwen 2.5 3B (Fast)</option>
              <option value="qwen2.5:7b">Qwen 2.5 7B (Balanced)</option>
              <option value="llama3.2:3b">Llama 3.2 3B (Fast)</option>
              <option value="mistral:7b">Mistral 7B (Balanced)</option>
            </select>
          </div>
        </div>
      </section>

      {/* Voice */}
      <section>
        <h2 className="text-xs font-mono text-dexter-cyan uppercase tracking-wider mb-2">
          Voice
        </h2>
        <div className="glass rounded-xl p-3 space-y-3">
          <div>
            <label className="text-xs text-dexter-dim block mb-1">TTS Voice</label>
            <select
              value={config.voice}
              onChange={(e) => setConfig({ ...config, voice: e.target.value })}
              className="w-full bg-dexter-surface border border-dexter-border rounded-lg px-3 py-2 text-sm text-dexter-white outline-none focus:border-dexter-cyan"
            >
              <option value="en_US-ryan-medium">Ryan (Male)</option>
              <option value="en_US-norman-medium">Norman (Male, Deep)</option>
              <option value="en_US-joe-medium">Joe (Male, Friendly)</option>
              <option value="en_US-bryce-medium">Bryce (Male, Young)</option>
              <option value="en_US-google_assistant-medium">Google Assistant</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-dexter-dim block mb-1">
              Volume: {Math.round(config.volume * 100)}%
            </label>
            <input
              type="range"
              min="0"
              max="100"
              value={config.volume * 100}
              onChange={(e) =>
                setConfig({ ...config, volume: parseInt(e.target.value) / 100 })
              }
              className="w-full accent-dexter-cyan"
            />
          </div>
        </div>
      </section>

      {/* Behavior */}
      <section>
        <h2 className="text-xs font-mono text-dexter-cyan uppercase tracking-wider mb-2">
          Behavior
        </h2>
        <div className="glass rounded-xl p-3 space-y-3">
          {[
            {
              key: "wake_word_enabled" as const,
              label: "Wake Word Detection",
              desc: "Say 'Hey Dexter' to activate",
            },
            {
              key: "always_on" as const,
              label: "Always Listening",
              desc: "Continuous listening without wake word",
            },
            {
              key: "auto_start" as const,
              label: "Auto-start with Windows",
              desc: "Launch Dexter when you log in",
            },
          ].map(({ key, label, desc }) => (
            <label
              key={key}
              className="flex items-center justify-between cursor-pointer"
            >
              <div>
                <p className="text-sm text-dexter-white">{label}</p>
                <p className="text-xs text-dexter-dim">{desc}</p>
              </div>
              <input
                type="checkbox"
                checked={config[key]}
                onChange={() =>
                  setConfig({ ...config, [key]: !config[key] })
                }
                className="w-4 h-4 accent-dexter-cyan"
              />
            </label>
          ))}
        </div>
      </section>

      {/* Learned Habits */}
      <section>
        <h2 className="text-xs font-mono text-dexter-cyan uppercase tracking-wider mb-2">
          Learned Patterns
        </h2>
        <div className="glass rounded-xl p-3">
          {habits ? (
            <pre className="text-[11px] text-dexter-dim whitespace-pre-wrap font-mono leading-relaxed">
              {habits}
            </pre>
          ) : (
            <p className="text-xs text-dexter-dim/50 italic">Learning from usage...</p>
          )}
          <button
            onClick={loadHabits}
            className="mt-2 text-[10px] text-dexter-cyan/60 hover:text-dexter-cyan font-mono transition-colors"
          >
            ↻ Refresh
          </button>
        </div>
      </section>

      {/* Save */}
      <button
        onClick={save}
        disabled={saving}
        className="w-full py-3 rounded-xl bg-dexter-cyan/10 border border-dexter-cyan/30 text-dexter-cyan hover:bg-dexter-cyan/20 transition-all text-sm font-medium disabled:opacity-50"
      >
        {saving ? "Saving..." : "Save Settings"}
      </button>

      <div className="text-center pb-4">
        <p className="text-[10px] text-dexter-dim/50 font-mono">
          DEXTER AI v1.0.0 · Fully Local
        </p>
      </div>
    </div>
  );
}
